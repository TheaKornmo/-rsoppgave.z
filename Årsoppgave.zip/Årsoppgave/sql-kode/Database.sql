
-- lager bruker tabellen
CREATE TABLE brukere (
  bruker_ID int IDENTITY(100,1) PRIMARY KEY,
  Brukernavn varchar(255) NOT NULL,
  passord varchar(255) NOT NULL);


INSERT INTO dbo.matretter (matrett, Beskrivelse, Alergener, Bilde)
VALUES ('Birria taco\r\n', 'Den diggeste tacoen du kan få tak i!', 'Gluten', 'https://cdn.discordapp.com/attachments/1072093868541104159/1111575927483289670/korni_birria_taco_with_lime_on_a_plate_with_black_background_3c6fc631-35ae-49a5-a411-24089f743e11.png'),
	   ('Lasagne', 'Deilig lasagne, med masse deilig ost og kjøtt. Denne vil du ikke gå glipp av <3', 'Laktose og gluten', 'https://cdn.discordapp.com/attachments/1072093868541104159/1111577114085425212/korni_lasagne_on_a_plate_with_black_background_f93e85a6-45f3-4205-94bf-8f1dbd5b4fcf.png'),
	   ('Sushi', '12 biter fritert lakse sushi, med mango og jordbær på toppen.' , 'Sjømat, mango, jordbær, gluten.', 'https://cdn.discordapp.com/attachments/1072093868541104159/1111577815163346974/korni_sushi_on_a_plate_with_black_background_6fbb6fcf-f741-4e25-9f6f-600812740874.png'),
	   ('baktpotet', 'Deilig baktpotet med ost, bacon, rømme, smør og mais.', 'Laktose', 'https://cdn.discordapp.com/attachments/1072093868541104159/1111578427812761640/korni_baked_potato_on_a_plate_with_black_background_07d73f7c-490c-4510-a750-20e9a8f0e8eb.png');



     
<div class="login-card-container">
    <div class="login-card">
        <div class="login-card-header">
            <h1>Logg på</h1>
                <div>Ansatt logg inn</div>
                </div> <!--login-card-header-->
                <form class="login-card-form" method="post">
                    <br>
                    <label for="fulltnavn">Fullt navn</label>
                    <input type="text" name="fulltnavn">
                    <br>
                    <label for="passord">Passord</label>
                    <input type="password" name="passord" id="passord">
                    <div class="check">
                    </div>
                    <br>
                    <button type="submit" name="submit">Logg på</button>
                </form>
                </div> 
        </div> 
        </form>


        <?php
if(isset($_POST['submit'])){
    $brukernavn = $_POST['fulltnavn'];
    $passord = $_POST['passord'];

    $dbc = mysqli_connect('localhost', 'root', '', 'webmeny')
        or die('Error connecting to MySQL server');

    $query = "SELECT fulltnavn, passord from brukere where fulltnavn='$brukernavn' and passord='$passord'";

    $result = mysqli_query($dbc, $query)
        or die('Error querying database.');

    mysqli_close($dbc);

    // var_dump($result);

    if($result->num_rows > 0){
        header('location: ansatt.php');
        var_dump('bra');
    }else{
        header('location: ikkeAnsatt.php');
        var_dump('ikke bra');
    }
}
?> 