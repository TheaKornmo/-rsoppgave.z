<?php
/* All database info man trenger for å koble til */
define('DB_SERVER', '172.22.252.163');
define('DB_USERNAME', 'Thea');
define('DB_PASSWORD', 'Kuben123');
define('DB_NAME', 'webmeny');
 
/* prøver å connecte ti mysql database*/
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// sjekker forbindelse
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>