
<!DOCTYPE html>
<html>
  
<head>
  <link rel="stylesheet" href="style.css">
</head>
  
<body>
    <?php
    $current_tab = 'faq';
    include('meny.php');
    ?>
  <h2 style="color:black; text-align:center">
   Ofte stilte spørsmål
  </h2>
  <div class="layout">
    <div class="accordion">
      <div class="accordion__question">
        <p>Hvor er resturanten?</p>
  
      </div>
      <div class="accordion__answer">
        <p>Resturanten ligger på oslo s</p>
      </div>
    </div>
  
    <div class="accordion">
      <div class="accordion__question">
        <p>Leverer dere?</p>
      </div>
  
      <div class="accordion__answer">
        <p>
        Ja, det pleier å ta rundt 45min med levering. Det koster 30kr ekstra om du skal ha levering.
        </p>
      </div>
    </div>

    <div class="accordion">
      <div class="accordion__question">
        <p>Hvem kan jeg kontakte hvis jeg står fast?</p>
      </div>
  
      <div class="accordion__answer">
        <p>
        Ron, fra brasil.
        </p>
      </div>
    </div>
  </div>
  
  

 


  <script src="faq.js"></script>
</body>
</html>