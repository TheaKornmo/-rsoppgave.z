    <?php
$current_tab = 'meny';
include('meny.php');
?>

<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to the login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Logout the user when the logout button is clicked
if (isset($_GET["logout"]) && $_GET["logout"] == true) {
    // Unset all of the session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to the login page
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font: 14px sans-serif;
        }

        .wrapper {
            width: 360px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>velkommen, <?php echo $_SESSION["username"]; ?></h2>
        <p><a href="connect.php?logout=true" class="btn btn-danger">Logg ut</a></p>
    </div>
</body>
</html>



<?php
$servername = "172.22.252.163";
$username = "Thea";
$password = "Kuben123";
$dataBaseNavn = "webmeny";


$conn = new mysqli($servername, $username, $password, $dataBaseNavn);



if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT matrett, alergener, beskrivelse, bilde FROM matretter";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        
        $alergener = $row["alergener"];
        $beskrivelse = $row["beskrivelse"];
        $matrett = $row['matrett'];
        $bilde = $row['bilde'];

        echo $matrett. " 
        " . $beskrivelse. "
        " . $alergener. "<br>";
        echo "<img src='$bilde' class='bildeMat'></img>";


    }
}  else {
    echo "0 results";
}


$conn->close();
?>







</form>


</body>
</html>